/*
 * SPDX-License-Identifier: Apache-2.0
 */

package main

// Fhirdlt stores a value
type Fhirdlt struct {
	Value string `json:"value"`
}

type FHIR_Compliant_Patient struct {
	Resourcetype string    `json:"Resourcetype"`
	Name         []Name    `json:"NameArray"`
	Gender       string    `json:"Gender"`
	BirthDate    string    `json:"BirthDate"`
	Telecom      []Telecom `json:"TelecomArray"`
	Address      []Address `json:"AddressArray"`
	Id           string    `json:"Id"`
	Active       bool      `json:"active"`
}

type Name struct {
	Use    string `json:"Use"`
	Family string `json:"Family"`
	Given  string `json:"Given"`
}

type Telecom struct {
	Value  string `json:"Value"`
	Use    string `json:"Use"`
	System string `json:"System"`
}

type Address struct {
	Use        string `json:"Use"`
	Line       string `json:"Line"`
	City       string `json:"City"`
	State      string `json:"State"`
	Country    string `json:"Country"`
	PostalCode string `json:"PostalCode"`
}

// type Period struct {
// 	Startdate string `json:"StartDate"`
// 	EndDate   string `json:"EndDate"`
// }
