/*
 * SPDX-License-Identifier: Apache-2.0
 */

package main

import (
	"github.com/hyperledger/fabric-contract-api-go/contractapi"
	"github.com/hyperledger/fabric-contract-api-go/metadata"
)

func main() {
	fhirdltpatientContract := new(FhirdltpatientContract)
	fhirdltpatientContract.Info.Version = "0.0.1"
	fhirdltpatientContract.Info.Description = "My Smart Contract"
	fhirdltpatientContract.Info.License = new(metadata.LicenseMetadata)
	fhirdltpatientContract.Info.License.Name = "Apache-2.0"
	fhirdltpatientContract.Info.Contact = new(metadata.ContactMetadata)
	fhirdltpatientContract.Info.Contact.Name = "John Doe"

	chaincode, err := contractapi.NewChaincode(fhirdltpatientContract)
	chaincode.Info.Title = "chaincode chaincode"
	chaincode.Info.Version = "0.0.1"

	if err != nil {
		panic("Could not create chaincode from FhirdltpatientContract." + err.Error())
	}

	err = chaincode.Start()

	if err != nil {
		panic("Failed to start chaincode. " + err.Error())
	}
}
